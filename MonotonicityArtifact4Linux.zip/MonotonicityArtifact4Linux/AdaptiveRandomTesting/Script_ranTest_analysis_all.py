import os
import sys

sampleSize = input('Give the MAX_SAMPLES limit:')
f=open('SampSize.txt', 'w')
f.write(sampleSize)
f.close()


noEx =input('Give the no. of times you would want each test case to execute:')
f=open('NoOfEx.txt', 'w')
f.write(noEx)
f.close()

os.system(r"python kNNScriptRan.py")

os.system(r"python MLPScriptRan.py")
os.system(r"python RanForestScriptRan.py")
os.system(r"python NBScriptRan.py")
os.system(r"python SVMScriptRan.py")
os.system(r"python AdaBoostScriptRan.py")
os.system(r"python GradBoostScriptRan.py")
os.system(r"python LogRegScriptRan.py")


os.remove('monFeature.txt')
os.remove('CandTestDataSet.csv')
os.remove('TestDataSet.csv')


os.remove('NoOfEx.txt')
os.remove('SampSize.txt')
