######   This is the Linux version of our code. This file will guide you to use our code to replicate the results of the paper in Linux. ##################



We have performed all of our experiments using python version 3.6.5. Hence, we request the user to use this python version while using our package. 
If you are having problem upgrading python version, you can install anaconda from here: https://docs.anaconda.com/anaconda/install/linux/. Follow the steps carefully while you do so.



This folder contains the following:

AdaptiveRandomTesting/	  		-- This folder contains the code and datasets needed to replicate the results for Adaptive Random Testing 						technique

PropertyBasedTestingRQ1/	  	-- This folder contains the code and datasets needed to replicate the results for Property based Testing 						               technique for research question 1 in the paper. As the settings of quickcheck (property based testing 								tool) are different for two research questions we have 2 seperate folders for property based 								testing.

PropertyBasedTestingRQ2/		-- This folder contains the code and datasets needed to replicate the results for Property based Testing 						               technique for research question 2 in the paper.


Pruning_Analysis/			-- This folder contains the code and datasets needed to replicate the results for verification based Testing 						               technique for research question 4 in the paper.

VerificationBasedTesting		-- This folder contains the code and datasets needed to replicate the results for verification based Testing 						               technique for research questions 1,2,3 in the paper.


IMP: Each of these folder further contains a README_LOCAL file where you will find the instructions to run the script for corresponding technique.

##Installing required packages

To install the required packages for running our experiments you need to first open the terminal inside this directory and run the following command:

$ pip install -r requirements.txt

This will install all the required packages and software in the current directory automatically. If you face problems during installation, we suggest you to create a new virtual environment in Linux and then install our packages which will help you to avoid errors during installation.


These steps should install all the packages required to run our code. However, if you still face any problem, you can install any required package by using 'pip':

$ pip install <package> 
 

The scripts will generate some intermediate files and datasets. In the end, the outputs will be stored in the Output folder. While running 
LightGbm algorithm some deprecation warnings might occur. Also, you might see some convergence problems with some ML algorithms.
This is expected. 

When running the scripts it will ask you for some inputs like: 1)MAX_SAMPLES limit and 2)No of times test cases to run. We have done our experiments by setting MAX_SAMPLES to 1000 and we ran each test cases at least 10 times. We suggest you to do the same as each of our technique involves some sort of randomness.
 
Please note that our approach involves lot of randomness. We try to avoid that by setting the input parameters to fixed values and running our test cases over and over again. Even after that we observed some randomness still persist. 

All the execution times written in output files are in seconds.





